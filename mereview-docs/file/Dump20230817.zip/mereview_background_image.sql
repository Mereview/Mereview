-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: i9c211.p.ssafy.io    Database: mereview
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `background_image`
--

DROP TABLE IF EXISTS `background_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `background_image` (
  `background_image_id` bigint NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) DEFAULT NULL,
  `modified_time` datetime(6) DEFAULT NULL,
  `store_file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `upload_file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `review_id` bigint DEFAULT NULL,
  PRIMARY KEY (`background_image_id`),
  KEY `FK3ubvucorexm1c07lkm5prq2j3` (`review_id`),
  CONSTRAINT `FK3ubvucorexm1c07lkm5prq2j3` FOREIGN KEY (`review_id`) REFERENCES `review` (`review_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `background_image`
--

LOCK TABLES `background_image` WRITE;
/*!40000 ALTER TABLE `background_image` DISABLE KEYS */;
INSERT INTO `background_image` VALUES (1,'2023-08-15 12:46:40.410855','2023-08-15 12:46:40.410855','91e2fe58-4ef7-4f09-80f6-1b6dcb736def.jpg','12.jpg',2),(2,'2023-08-15 12:54:04.575694','2023-08-15 12:54:04.575694','0d25a6d6-22a2-4874-8f74-ce498e9a9eb7.jpg','1.jpg',3),(4,'2023-08-15 14:41:46.588506','2023-08-15 14:41:46.588506','54ddcd40-456d-4163-be1f-791774c8567b.jpg','스즈메.jpg',6),(5,'2023-08-15 15:03:32.527742','2023-08-15 15:03:32.527742','bd842265-1a3f-42b8-8019-100bdda2c171.jpg','12.jpg',7),(7,'2023-08-16 06:10:21.598004','2023-08-16 06:10:21.598004','8c21e9b4-6d29-481e-8389-a346a2c0e8b1.jpg','image.jpg',11),(9,'2023-08-16 08:36:47.795507','2023-08-16 08:36:47.795507','9ad1827f-c04b-4497-baa1-47f345379ffa.jpg','Yd0RETTKVfXKg3gvmaXl9g.jpg',13),(11,'2023-08-16 12:36:03.332127','2023-08-16 12:36:03.332127','de44eda7-d1c4-4e8c-a0b4-5da3bef49acc.jpg','image.jpg',15),(12,'2023-08-17 00:12:42.715526','2023-08-17 00:12:42.715526','16814cb5-6938-4fe6-8489-6bcd1c9da7e8.jpg','image.jpg',16),(13,'2023-08-17 00:14:44.922419','2023-08-17 00:14:44.922419','de4a01f2-c4ff-499d-aede-6c8b53e2db28.jpg','mereview_img458b5ba8-dcde-46e9-a97e-f39f392355ec.jpg',17),(15,'2023-08-17 01:58:53.074700','2023-08-17 01:58:53.074700','0035b19a-8214-42cb-8273-a6334e438b32.jpg','image.jpg',19),(17,'2023-08-17 04:11:33.482284','2023-08-17 04:11:33.482284','939129b3-b93a-45b3-b960-8fd8e8b71b56.jpg','image.jpg',21),(19,'2023-08-17 04:23:02.542989','2023-08-17 04:23:02.542989','725b6f5a-8296-42a4-890b-edcd87b52ed8.jpg','image.jpg',23),(22,'2023-08-17 05:10:33.814933','2023-08-17 05:10:33.814933','ec47ad5c-3314-4c1e-a96e-42348cb695a4.jpg','image.jpg',26),(23,'2023-08-17 06:23:27.871360','2023-08-17 06:23:27.871360','53ee7f46-5726-4d56-adf7-8c276551a524.jpg','image.jpg',27),(24,'2023-08-17 06:26:25.919049','2023-08-17 06:26:25.919049','a3c4e6e4-2b41-4652-9831-9dce9ce8311f.gif','15b0c5126012b1c15e3e5744bdf4de98.gif',28),(25,'2023-08-17 06:50:27.019963','2023-08-17 06:50:27.019963','5d577389-abe3-4537-8d41-cbe78f80d1cd.jpg','image.jpg',29),(26,'2023-08-17 07:19:53.664149','2023-08-17 07:19:53.664149','7beb3a17-915e-4cb5-8af0-67f75dbd8547.jpg','tzgxqQ5jjZ7jk_EtEIoTfA.jpg',30),(27,'2023-08-17 07:26:31.431318','2023-08-17 07:26:31.431318','cc318b39-731a-4e58-bd40-b225a0577591.gif','elemetnal.gif',31),(28,'2023-08-17 07:38:08.572591','2023-08-17 07:38:08.572591','c1679018-8b3f-402d-8139-c713f7a96442.jpg','image.jpg',32),(29,'2023-08-17 08:40:11.787487','2023-08-17 08:40:11.787487','a0109fed-b5aa-4e54-a663-74461a0334f6.jpg','Yd0RETTKVfXKg3gvmaXl9g.jpg',33),(30,'2023-08-17 08:41:30.256206','2023-08-17 08:41:30.256206','905cfe45-8e30-46ed-83a3-ee613d0ada95.png','레디 플레이어 원.png',34),(31,'2023-08-17 08:43:54.070042','2023-08-17 08:43:54.070042','00d26f19-7d57-469d-aa3c-e4d4febb8761.jpg','image.jpg',35),(32,'2023-08-17 08:48:37.055722','2023-08-17 08:48:37.055722','7ac77c9b-7470-47e4-a7f4-9600f0c06303.jpg','스즈메.jpg',36);
/*!40000 ALTER TABLE `background_image` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-17 17:51:22
