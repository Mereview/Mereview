-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: i9c211.p.ssafy.io    Database: mereview
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `profile_image`
--

DROP TABLE IF EXISTS `profile_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profile_image` (
  `profile_image_id` bigint NOT NULL,
  `created_time` datetime(6) DEFAULT NULL,
  `modified_time` datetime(6) DEFAULT NULL,
  `store_file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `upload_file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `member_id` bigint DEFAULT NULL,
  PRIMARY KEY (`profile_image_id`),
  KEY `FKp0eguv2qtavl9b9ocontxoheo` (`member_id`),
  CONSTRAINT `FKp0eguv2qtavl9b9ocontxoheo` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile_image`
--

LOCK TABLES `profile_image` WRITE;
/*!40000 ALTER TABLE `profile_image` DISABLE KEYS */;
INSERT INTO `profile_image` VALUES (2,'2023-08-15 11:00:49.284866','2023-08-15 16:06:57.075662','d0918129-cb97-47a3-9c60-76811ddf21da.gif','597e4d0f30e21478a8ba5ea276106038.gif',2),(4,'2023-08-15 11:41:57.227448','2023-08-15 11:41:57.227448','10b17739-7d0f-4307-88de-3a432fa7109f.gif','mereview_img750824d3-45f9-42df-baa3-434bd63f9ae9.gif',3),(6,'2023-08-15 12:01:12.144479','2023-08-17 06:54:33.662438','b14cd279-c5c4-4c39-b314-990edc1a69d0.png','리뷰카드.png',4),(8,'2023-08-15 12:57:15.952383','2023-08-15 12:57:15.952383','7591e0fe-ad04-4466-9a8b-64c8d1dc5876.png','cosplayer.png',5),(24,'2023-08-16 05:13:15.109211','2023-08-16 05:13:15.109211','7bb1ac7b-e0c7-44db-90ad-270e1ded84d2.png','test.png',8),(29,'2023-08-17 04:27:14.824404','2023-08-17 04:27:14.824404','321c36e4-74eb-48e7-a771-dcb66a15c016.jpeg','중절무.jpeg',12);
/*!40000 ALTER TABLE `profile_image` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-17 17:51:09
