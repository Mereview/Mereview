package com.ssafy.mereview.common.util;

public class SizeConstants {
    public static final int PAGE_SIZE = 10;
    public static final int ATTRACTION_SIZE = 15;
}
