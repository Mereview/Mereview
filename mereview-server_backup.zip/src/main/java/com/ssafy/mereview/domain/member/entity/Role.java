package com.ssafy.mereview.domain.member.entity;

public enum Role {
    ADMIN, USER, DELETE
}
