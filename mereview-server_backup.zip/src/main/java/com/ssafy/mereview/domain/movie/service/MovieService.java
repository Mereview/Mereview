package com.ssafy.mereview.domain.movie.service;

import javax.transaction.Transactional;

@Transactional
public interface MovieService {


}
