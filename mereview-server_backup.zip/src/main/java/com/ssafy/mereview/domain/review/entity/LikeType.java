package com.ssafy.mereview.domain.review.entity;

public enum LikeType {
    LIKE, DISLIKE
}
