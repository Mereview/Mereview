package com.ssafy.mereview.domain.review.service;

public interface MovieService {
}
