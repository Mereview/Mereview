package com.ssafy.mereview.domain.movie.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface MovieRepository {


}
