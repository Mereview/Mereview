package com.ssafy.mereview.domain.review.entity;

public enum EvaluationType {
    LIKE, DISLIKE, BAD
}
