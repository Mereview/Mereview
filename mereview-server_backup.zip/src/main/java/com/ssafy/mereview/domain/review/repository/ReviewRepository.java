package com.ssafy.mereview.domain.review.repository;

public interface ReviewRepository {
}
