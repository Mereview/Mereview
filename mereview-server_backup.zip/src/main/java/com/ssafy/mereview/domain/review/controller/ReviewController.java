package com.ssafy.mereview.domain.review.controller;

public class ReviewController {
}
