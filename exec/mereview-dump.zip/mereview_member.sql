-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: i9c211.p.ssafy.io    Database: mereview
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `member_id` bigint NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) DEFAULT NULL,
  `modified_time` datetime(6) DEFAULT NULL,
  `birth_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `introduce` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nickname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'USER',
  PRIMARY KEY (`member_id`),
  UNIQUE KEY `UK_hh9kg6jti4n1eoiertn2k6qsc` (`nickname`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (1,'2023-08-15 10:38:35.019189','2023-08-15 10:38:35.019189','1997-08-04','longbright0804@gmail.com','MALE',NULL,'김웅서짱','$2a$10$4L15kO3Osjpo/qL3oL9bU.YV5K1hbW65yJ5buVi/gx3.7nk9HEphS','USER'),(2,'2023-08-15 11:00:49.278675','2023-08-15 11:00:49.278675','1997-09-10','jinhyugn@gmail.com','MALE',NULL,'미리쀼쀼','$2a$10$rYbsOnz77p7x0e31QO0Vk.OUG5gecQS1XYE4WfXEk2QO1oJn4s1qG','USER'),(3,'2023-08-15 11:41:57.184940','2023-08-15 16:13:14.548749','1994-04-07','kus11410@naver.com','MALE','반갑다.','우산동 이동진','$2a$10$qtYb5uD7k1K9YVNxMRpHWuWcUt3qwwzkzDK..UN4321wq1bz00b8q','USER'),(4,'2023-08-15 12:01:12.142172','2023-08-16 06:14:13.458325','1993-08-28','duljjii@naver.com','MALE','ㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇ\n\nㅋㅋㅋㅋㅋㅋㅋ','들쮜','$2a$10$LkEC6Y3S66/JHwd.yXnu5eFedZRd25wJj8mSH1m8v4BjCNqdC0/7W','USER'),(5,'2023-08-15 12:57:15.943579','2023-08-15 12:57:15.943579','1998-07-04','ungseo@gmail.com','FEMALE',NULL,'킹반인','$2a$10$m0ltXCZBuTqig3EgZ3GUR.iMRDW.54yXmMv5DpGX.SNJF4twLog.6','USER'),(6,'2023-08-15 14:28:43.744968','2023-08-16 17:28:57.367451','2023-08-24','byuri1356@gmail.com','MALE','죄송합니다','버그제보해주세요','$2a$10$2QuMaREHjyH42ii7fojb3.Un7CUBg0A.BVIxPuQXV2h41KwATcml6','USER'),(7,'2023-08-15 16:23:59.429017','2023-08-15 16:23:59.429017','2023-08-16','s688922@gmail.com','FEMALE',NULL,'최배지','$2a$10$ToLMPzSBsFX4lxggqyffReWXlNZ7Sxv7wEgE91oAp2rS5FEqoyKNm','USER'),(8,'2023-08-16 05:13:15.099890','2023-08-16 05:13:15.099890','2023-08-15','mji4209@naver.com','MALE',NULL,'chati','$2a$10$DkPxNEUXsoRFmGoyhEOOv.pCE5AGUOUanCKLoO59/Wma/jM21BltW','USER'),(9,'2023-08-16 05:15:33.372078','2023-08-17 16:15:01.532268','1993-08-28','ssafy@ssafy.com','MALE','우산동 영잘알','싸피','$2a$10$GWtVmLhfwwDUSCAKSUrC6uCFNRyqI4Bkb5oGJMiNW8E/xg.xlnfdm','USER'),(10,'2023-08-16 23:56:11.501077','2023-08-16 23:56:11.501077','1996-03-08','hchyi259@naver.com','MALE',NULL,'이수민','$2a$10$hJLYPwke.hKqdhn.iSBKCuckuF2dc/Ao900jq0ZpTgDSwVnu0ydc2','USER'),(11,'2023-08-17 04:15:32.085527','2023-08-17 04:33:57.426529','2023-08-17','wjs_5025@naver.com','MALE',NULL,'최영환돼지','$2a$10$lj1/yebaO9xULyPYwt/uMeZll4DPUGbsFFTh5pTdv3QKTKS.eJhqe','DELETED'),(12,'2023-08-17 04:27:14.814182','2023-08-17 04:27:14.814182','1997-05-16','zzckckck3@naver.com','MALE',NULL,'엄준식','$2a$10$Gwa/RlFXhXuQuH7y5sMXe.I/7cYtsyFI6s2jJdDso11HRQn8YxyJe','USER'),(13,'2023-08-17 13:52:55.100195','2023-08-17 15:06:00.900608','1994-04-07','ungseo@daum.net','MALE',NULL,'애니메이션참좋아하는사람','$2a$10$6zVCvCmofG1EExTiviGyTuEZdWox5pkYGA6YjuOuWlu7RPiaxuFau','USER'),(14,'2023-08-18 00:39:03.417970','2023-08-18 00:39:03.417970','1997-09-10','travery.master@gmail.com','MALE',NULL,'미리뷰','$2a$10$QLk5r4A/xPv1qut7bZtjl.Wn81uENOBR.9SIqZRmI8F.wXuVIrH6m','USER');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-18 12:00:06
